# Atomberg Share-of-Voice (SoV) Agent
This package contains a simple, extensible prototype agent to estimate Share-of-Voice (SoV) for the keyword "smart fan" on YouTube.

## What it contains
- `main.py` — CLI entry point. Fetches top-N YouTube results (API or lightweight scrape), computes Results SoV and Directional Engagement SoV, and produces a CSV report.
- `utils.py` — helper functions for YouTube Data API and simple scraping fallback.
- `requirements.txt` — Python packages used.
- `.env.example` — example for environment variables (YouTube API key).
- `notebooks/` — suggested notebook placeholder.
- `two-pager/Atomberg_SoV_YouTube_TwoPager.docx` — the two-page brief created earlier.

## Quickstart
1. Create a Python venv, install dependencies from `requirements.txt`.
2. Copy `.env.example` to `.env` and set `YOUTUBE_API_KEY` if available.
3. Run:
   ```bash
   python main.py --query "smart fan" --topn 20 --out report.csv
   ```

## Notes
- If `YOUTUBE_API_KEY` is present, the script will use the YouTube Data API for accurate view/comment counts. Otherwise, it uses a lightweight HTML parse fallback which may be less reliable.
- Sentiment analysis uses TextBlob (simple polarity). For production, swap in a modern transformer model.
- This repo is a prototype for demonstration and should be extended for production (rate-limits, retries, robust parsing).
