import os, re, math
import requests
from bs4 import BeautifulSoup
import pandas as pd
from textblob import TextBlob
from urllib.parse import quote_plus
from googleapiclient.discovery import build

YT_API_KEY = os.getenv('YOUTUBE_API_KEY') or None

def _clean_text(s):
    return (s or '').strip()

def fetch_top_youtube(query, topn=20):
    """Fetch topn YouTube search results. Use API when key is available; else fallback to HTML parsing."""
    if YT_API_KEY:
        return _fetch_top_youtube_api(query, topn)
    else:
        return _fetch_top_youtube_scrape(query, topn)

def _fetch_top_youtube_api(query, topn=20):
    service = build('youtube', 'v3', developerKey=YT_API_KEY)
    resp = service.search().list(q=query, part='snippet', maxResults=min(50, topn), type='video').execute()
    items = resp.get('items', [])[:topn]
    results = []
    ids = [i['id']['videoId'] for i in items]
    # fetch stats
    stats = {}
    if ids:
        stats_resp = service.videos().list(part='snippet,statistics', id=','.join(ids)).execute()
        for v in stats_resp.get('items',[]):
            stats[v['id']] = v
    for it in items:
        vid = it['id']['videoId']
        s = stats.get(vid, {})
        results.append({
            'title': _clean_text(it['snippet']['title']),
            'url': f"https://www.youtube.com/watch?v={vid}",
            'channel': it['snippet'].get('channelTitle'),
            'published': it['snippet'].get('publishedAt'),
            'views': int(s.get('statistics',{}).get('viewCount') or 0),
            'raw': it
        })
    return results

def _fetch_top_youtube_scrape(query, topn=20):
    # Lightweight HTML parse of search page. Not bulletproof; for prototype only.
    q = quote_plus(query)
    url = f"https://www.youtube.com/results?search_query={q}"
    headers = { 'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0' }
    r = requests.get(url, headers=headers, timeout=15)
    soup = BeautifulSoup(r.text, 'html.parser')
    results = []
    # YouTube embeds initial data in a script tag -- try extracting video links from hrefs
    for a in soup.select('a#video-title')[:topn]:
        title = _clean_text(a.get('title') or a.text)
        href = a.get('href')
        vid = None
        if href and 'watch?v=' in href:
            vid = href.split('watch?v=')[-1].split('&')[0]
        results.append({
            'title': title,
            'url': f'https://www.youtube.com{href}' if href else None,
            'channel': None,
            'published': None,
            'views': 0,
            'raw': None
        })
    return results

def simple_sentiment(text):
    tb = TextBlob((text or ''))
    return float(tb.sentiment.polarity)

def compute_sov(results, focus_brands=None):
    """Compute simple SoV metrics from `results` list.
    returns (summary_dict, rows_list)
    """
    focus_brands = focus_brands or ['Atomberg']
    rows = []
    total_engagement = 0.0
    brand_eng = {b:0.0 for b in focus_brands}
    brand_count = {b:0 for b in focus_brands}
    for r in results:
        title = r.get('title','')
        views = int(r.get('views') or 0)
        # engagement_index: log(views+1) to reduce skew
        eng = math.log(views+1) if views>0 else 1.0
        total_engagement += eng
        mentions = []
        for b in focus_brands:
            if re.search(r'\b'+re.escape(b)+r'\b', title, flags=re.I):
                mentions.append(b)
                brand_eng[b] += eng
                brand_count[b] += 1
        rows.append({
            'title': title,
            'url': r.get('url'),
            'views': views,
            'channel': r.get('channel'),
            'published': r.get('published'),
            'brand_mentions': '|'.join(mentions) or '',
            'engagement_index': eng,
            'title_sentiment': simple_sentiment(title)
        })
    # compute shares
    summary = {}
    total_results = max(1, len(results))
    summary['total_results'] = total_results
    for b in focus_brands:
        summary[f'{b}_results_share'] = f"{brand_count[b]}/{total_results} = {brand_count[b]/total_results:.2%}"
        summary[f'{b}_engagement_share'] = f"{brand_eng[b]:.4f}/{total_engagement:.4f} = {(brand_eng[b]/total_engagement if total_engagement>0 else 0):.2%}"
    return summary, rows
