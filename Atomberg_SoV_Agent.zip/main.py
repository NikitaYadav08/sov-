import argparse, os, csv
from utils import fetch_top_youtube, compute_sov, simple_sentiment
from dotenv import load_dotenv

load_dotenv()

def main():
    parser = argparse.ArgumentParser(description='Atomberg SoV Agent - YouTube (prototype)')
    parser.add_argument('--query', type=str, required=True, help='Search query e.g. "smart fan"')
    parser.add_argument('--topn', type=int, default=20, help='Top N results to fetch')
    parser.add_argument('--out', type=str, default='report.csv', help='CSV output file')
    args = parser.parse_args()

    print(f"Running SoV agent for query={args.query!r} topn={args.topn}")
    results = fetch_top_youtube(args.query, args.topn)
    print(f"Fetched {len(results)} results (may be fewer if parsing failed)")

    sov_summary, rows = compute_sov(results, focus_brands=['Atomberg','Havells','Crompton','Orient'])
    print('Computed SoV summary:')
    for k,v in sov_summary.items():
        print(f"  {k}: {v}")

    # write CSV
    with open(args.out, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=['title','url','views','channel','published','brand_mentions','engagement_index','title_sentiment'])
        writer.writeheader()
        for r in rows:
            writer.writerow(r)
    print(f"Wrote report to {args.out}")

if __name__ == '__main__':
    main()
